import RPi.GPIO as GPIO
import config
import time

class SensorArray:
    """Handles the QTR-8RC Reflectance Sensor Array for Line Following."""
    def __init__(self):
        GPIO.setmode(config.GPIO_MODE)
        self.pins = config.IR_PINS
        # Initial pin setup will toggle dynamically between OUT and IN for the RC sweep
        for pin in self.pins:
            GPIO.setup(pin, GPIO.IN)

    def read_raw(self):
        """Reads QTR-8RC discharge times and returns a boolean array
        (True if over a black line)."""
        discharge_times = [0.0] * len(self.pins)
        
        # 1. Drive all pins HIGH to charge the sensor capacitors
        for pin in self.pins:
            GPIO.setup(pin, GPIO.OUT)
            GPIO.output(pin, GPIO.HIGH)
            
        # 2. Wait ~10us minimum for capacitors to charge
        time.sleep(0.000020) # 20us for safety
        
        # 3. Quickly set all pins to INPUT to measure discharge
        for pin in self.pins:
            GPIO.setup(pin, GPIO.IN)
            
        # 4. Measure discharge time
        start_time = time.time()
        active_pins = list(self.pins)
        
        # Timeout after 2.5ms (completely black line takes long to discharge)
        timeout = 0.0025 
        
        while active_pins and (time.time() - start_time) < timeout:
            for pin in active_pins[:]: # Iterate over copy
                if GPIO.input(pin) == GPIO.LOW:
                    idx = self.pins.index(pin)
                    discharge_times[idx] = time.time() - start_time
                    active_pins.remove(pin)
                    
        # Apply timeout ceiling for any extremely dark surfaces
        max_duration = time.time() - start_time
        for pin in active_pins:
            idx = self.pins.index(pin)
            discharge_times[idx] = max_duration
            
        # 5. Thresholding
        # A white surface quickly reflects IR, discharging the capacitor (e.g. < 0.5ms)
        # A black line absorbs IR, taking longer to discharge (e.g. > 1.0ms)
        # We define a threshold of 1.0ms (0.001 seconds)
        THRESHOLD = 0.0010
        
        # Return True for pins aiming at a BLACK line
        return [dt > THRESHOLD for dt in discharge_times]
        
    def get_position_error(self):
        """
        Calculates the error scalar for PID line following.
        Left sensors [-4, -3, -2, -1], Right sensors [1, 2, 3, 4]
        Returns 0 if line is centered.
        Returns a special flag (e.g., 100) if a '+' intersection is detected.
        """
        readings = self.read_raw()
        
        # Check for intersection (all/most sensors triggered)
        if sum(readings) >= 6: 
            return "INTERSECTION"
            
        # No line detected
        if sum(readings) == 0:
            return "LOST"

        # Calculate weighted average for position error
        weights = [-4, -3, -2, -1, 1, 2, 3, 4]
        weighted_sum = sum(r * w for r, w in zip(readings, weights))
        
        return weighted_sum / sum(readings)

class UltrasonicSensor:
    """Handles the HC-SR04 for Obstacle Avoidance."""
    def __init__(self):
        GPIO.setmode(config.GPIO_MODE)
        GPIO.setup(config.ULTRASONIC_TRIG, GPIO.OUT)
        GPIO.setup(config.ULTRASONIC_ECHO, GPIO.IN)
        # Ensure Trigger is LOW
        GPIO.output(config.ULTRASONIC_TRIG, False)
        time.sleep(0.5)

    def get_distance(self):
        """Returns distance in cm to the nearest obstacle. Returns max float if timeout."""
        GPIO.output(config.ULTRASONIC_TRIG, True)
        time.sleep(0.00001)
        GPIO.output(config.ULTRASONIC_TRIG, False)

        pulse_start = time.time()
        timeout = pulse_start + 0.04 # Max round trip time (roughly 6+ meters)

        while GPIO.input(config.ULTRASONIC_ECHO) == 0:
            pulse_start = time.time()
            if pulse_start > timeout:
                return float('inf')

        pulse_end = time.time()
        timeout = pulse_end + 0.04
        
        while GPIO.input(config.ULTRASONIC_ECHO) == 1:
            pulse_end = time.time()
            if pulse_end > timeout:
                return float('inf')

        pulse_duration = pulse_end - pulse_start
        # Speed of sound is 343m/s (34300 cm/s). Distance = (Time x Speed)/2
        distance = pulse_duration * 17150
        return round(distance, 2)
        
    def is_obstacle_ahead(self):
        dist = self.get_distance()
        return dist < config.OBSTACLE_DISTANCE_THRESHOLD_CM
