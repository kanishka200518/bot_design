import RPi.GPIO as GPIO
import config
import time

class CameraServo:
    def __init__(self):
        GPIO.setmode(config.GPIO_MODE)
        GPIO.setup(config.SERVO_PIN, GPIO.OUT)
        self.pwm = GPIO.PWM(config.SERVO_PIN, config.SERVO_FREQ)
        self.pwm.start(0)
        self.set_angle(0)

    def set_angle(self, angle):
        """
        Angles accepted: -45, 0, 45 or up to -90, 90 theoretically.
        Center (0 degrees) maps to duty cycle ~7.5.
        -90 is ~2.5, +90 is ~12.5.
        """
        # Map angle -90..90 to duty cycle 2.5..12.5
        duty_cycle = 7.5 + (angle / 90.0) * 5.0
        
        # Enable GPIO to move servo, then let it rest to prevent jitter
        self.pwm.ChangeDutyCycle(duty_cycle)
        time.sleep(0.5) 
        self.pwm.ChangeDutyCycle(0) 

    def cleanup(self):
        self.pwm.stop()
