import RPi.GPIO as GPIO
import config
import time

class MotorController:
    def __init__(self):
        GPIO.setmode(config.GPIO_MODE)
        GPIO.setwarnings(False)

        # Setup Left Motor
        GPIO.setup(config.ENA, GPIO.OUT)
        GPIO.setup(config.IN1, GPIO.OUT)
        GPIO.setup(config.IN2, GPIO.OUT)
        # 100Hz provides maximum physical pushing torque for heavy robots
        self.pwmA = GPIO.PWM(config.ENA, 100)
        self.pwmA.start(0)

        # Setup Right Motor
        GPIO.setup(config.ENB, GPIO.OUT)
        GPIO.setup(config.IN3, GPIO.OUT)
        GPIO.setup(config.IN4, GPIO.OUT)
        self.pwmB = GPIO.PWM(config.ENB, 100)
        self.pwmB.start(0)

        self.current_left = 0
        self.current_right = 0
        self.stop()

    def set_speed(self, left_speed, right_speed):
        """Sets the power mapped between 0-100 with a Friction-Breaking Kickstart"""
        target_left = max(0, min(100, left_speed))
        target_right = max(0, min(100, right_speed))
        
        # KICK-START: If starting from a dead stop, blast 100% power for 50ms 
        # to shatter the mechanical gearbox static friction before settling to the target speed.
        if (self.current_left == 0 and target_left > 0) or (self.current_right == 0 and target_right > 0):
            self.pwmA.ChangeDutyCycle(100 if target_left > 0 else 0)
            self.pwmB.ChangeDutyCycle(100 if target_right > 0 else 0)
            time.sleep(0.05) # 50 milliseconds of pure torque
            
        self.pwmA.ChangeDutyCycle(target_left)
        self.pwmB.ChangeDutyCycle(target_right)
        
        self.current_left = target_left
        self.current_right = target_right

    def move(self, left_speed, right_speed):
        """Move wheels. Positive speed = forward, negative = reverse"""
        
        # Deadband / Friction Clamp
        MIN_POWER = 35
        
        abs_left = abs(left_speed)
        abs_right = abs(right_speed)
        
        # Only clamp if the motor is actually commanded to move 
        # (Allows 0 to actually stop the motor)
        if abs_left > 0 and abs_left < MIN_POWER:
            abs_left = MIN_POWER
        elif abs_left > 100:
            abs_left = 100
            
        if abs_right > 0 and abs_right < MIN_POWER:
            abs_right = MIN_POWER
        elif abs_right > 100:
            abs_right = 100

        # Left Motor Direction (Reversed Topology)
        if left_speed > 0:
            GPIO.output(config.IN1, GPIO.LOW)
            GPIO.output(config.IN2, GPIO.HIGH)
        elif left_speed < 0:
            GPIO.output(config.IN1, GPIO.HIGH)
            GPIO.output(config.IN2, GPIO.LOW)
        else:
            GPIO.output(config.IN1, GPIO.LOW)
            GPIO.output(config.IN2, GPIO.LOW)
            
        # Right Motor Direction (Reversed Topology)
        if right_speed > 0:
            GPIO.output(config.IN3, GPIO.LOW)
            GPIO.output(config.IN4, GPIO.HIGH)
        elif right_speed < 0:
            GPIO.output(config.IN3, GPIO.HIGH)
            GPIO.output(config.IN4, GPIO.LOW)
        else:
            GPIO.output(config.IN3, GPIO.LOW)
            GPIO.output(config.IN4, GPIO.LOW)

        self.set_speed(abs_left, abs_right)

    def forward(self, speed=config.DEFAULT_SPEED):
        self.move(speed, speed)

    def backward(self, speed=config.DEFAULT_SPEED):
        self.move(-speed, -speed)

    def turn_left(self, speed=config.TURN_SPEED):
        self.move(-speed, speed)

    def turn_right(self, speed=config.TURN_SPEED):
        self.move(speed, -speed)

    def stop(self):
        self.move(0, 0)
        
    def cleanup(self):
        self.stop()
        self.pwmA.stop()
        self.pwmB.stop()
