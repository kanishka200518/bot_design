import cv2
import numpy as np
import threading
import json
import time
try:
    from pyzbar.pyzbar import decode
    ZBAR_AVAILABLE = True
except Exception as e:
    print(f"Warning: pyzbar not available ({type(e).__name__}: {e}). QR decoding disabled.")
    ZBAR_AVAILABLE = False
    
try:
    from tflite_runtime.interpreter import Interpreter
except ImportError:
    # Full TF doesn't always package .lite cleanly on all Windows distributions.
    # For local PC testing, we mock the Interpreter so the UI routing still works.
    print("Warning: tflite_runtime not installed. Object Detection disabled for local test.")
    class Interpreter:
        def __init__(self, model_path): pass
        def allocate_tensors(self): pass
        def get_input_details(self): return [{'shape': [1, 224, 224, 3], 'index': 0}]
        def get_output_details(self): return [{'index': 0}]
        def set_tensor(self, idx, data): pass
        def invoke(self): pass
        def get_tensor(self, idx): return [[0.0]]
    
import config

class VisionSystem:
    def __init__(self, model_path, labels_path):
        self.camera = cv2.VideoCapture(config.CAMERA_INDEX)
        self.camera.set(cv2.CAP_PROP_FRAME_WIDTH, config.FRAME_WIDTH)
        self.camera.set(cv2.CAP_PROP_FRAME_HEIGHT, config.FRAME_HEIGHT)
        
        # Latest data safely accessible by other threads (like Flask Web App)
        self.latest_frame = None
        self.latest_detections = []  # List of dicts: {'Category': X, 'Content': Y}
        self.running = False
        self.lock = threading.Lock()
        
        # Load TFLite Model
        try:
            self.interpreter = Interpreter(model_path=model_path)
            self.interpreter.allocate_tensors()
            self.input_details = self.interpreter.get_input_details()
            self.output_details = self.interpreter.get_output_details()
            
            with open(labels_path, 'r') as f:
                self.labels = json.load(f)
            self.model_loaded = True
            print("TFLite Model loaded successfully.")
        except Exception as e:
            print(f"Warning: Could not load TFLite model: {e}")
            self.model_loaded = False

    def start(self):
        self.running = True
        self.thread = threading.Thread(target=self._update, daemon=True)
        self.thread.start()

    def stop(self):
        self.running = False
        if hasattr(self, 'thread'):
            self.thread.join()
        self.camera.release()

    def _update(self):
        """Background thread continuously grabbing frames and running inference."""
        while self.running:
            success, frame = self.camera.read()
            if not success:
                time.sleep(0.1)
                continue
                
            current_detections = []

            # 1. QR Code Decoding via PyZbar
            if ZBAR_AVAILABLE:
                qr_codes = decode(frame)
                for qr in qr_codes:
                    qr_data = qr.data.decode('utf-8')
                    current_detections.append({
                        "Category": "QR Code",
                        "Content": qr_data
                    })
                    # Draw bounding box for visualization on stream
                    pts = np.array([qr.polygon], np.int32)
                    pts = pts.reshape((-1, 1, 2))
                    cv2.polylines(frame, [pts], True, (255, 0, 0), 2)
                    cv2.putText(frame, qr_data, (qr.rect.left, qr.rect.top - 10),
                                cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 0, 0), 2)

            # 2. TFLite Classifier Inference (if loaded)
            if self.model_loaded:
                # Preprocess frame for MobileNetV2 (resize to 224x224, normalize to [-1, 1])
                input_shape = self.input_details[0]['shape']
                resized = cv2.resize(frame, (input_shape[1], input_shape[2]))
                input_data = np.expand_dims(resized, axis=0).astype(np.float32)
                input_data = (input_data / 127.5) - 1.0 # normalize tf applications

                self.interpreter.set_tensor(self.input_details[0]['index'], input_data)
                self.interpreter.invoke()
                output_data = self.interpreter.get_tensor(self.output_details[0]['index'])[0]
                
                # Get prediction if confidence is high enough
                best_idx = np.argmax(output_data)
                confidence = output_data[best_idx]
                
                if confidence > 0.6: # 60% confidence threshold
                    predicted_label = self.labels[best_idx]
                    # Label format is "Category_Content"
                    if "_" in predicted_label:
                        cat, cont = predicted_label.split("_", 1)
                    else:
                        cat = predicted_label
                        cont = predicted_label
                        
                    current_detections.append({
                        "Category": cat,
                        "Content": cont,
                        "Confidence": round(float(confidence), 2)
                    })
                    
                    cv2.putText(frame, f"{cat}: {cont} ({confidence:.2f})", 
                                (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)

            # Update shared state
            with self.lock:
                self.latest_frame = frame
                self.latest_detections = current_detections

    def read_frame_jpeg(self):
        """Returns jpeg encoded bytes of the latest frame for web streaming."""
        with self.lock:
            if self.latest_frame is None:
                return None
            ret, jpeg = cv2.imencode('.jpg', self.latest_frame)
            return jpeg.tobytes() if ret else None
            
    def get_detections(self):
        """Returns the current list of detected items."""
        with self.lock:
            return self.latest_detections
